# Iconos PWA

Coloca aquí los siguientes archivos de iconos para la PWA:

- `icon-192x192.png` (192x192px)
- `icon-512x512.png` (512x512px)

Estos iconos se usan en el manifest de la PWA y para la instalación como aplicación.

Puedes generar estos iconos usando cualquier herramienta de diseño o generador de iconos PWA en línea.

