# PWA Scanner - Control de Entradas

Aplicación PWA **instalable** y **offline-first** para control de entradas en eventos, optimizada para funcionar en la puerta con mala conectividad o sin Internet.

## 🚀 Características PWA

- ✅ **Instalable**: Se puede instalar como app nativa en móviles y desktop
- ✅ **Funciona offline**: Completamente funcional sin conexión después del snapshot inicial
- ✅ **Sincronización automática**: Actualiza automáticamente cuando vuelve la conexión
- ✅ **Mala señal**: Maneja timeouts y usa cache cuando la conexión es lenta
- ✅ **Actualización automática**: Detecta y aplica nuevas versiones automáticamente

## Características

- ✅ **Offline-First**: Funciona completamente sin conexión después del snapshot inicial
- ✅ **Sincronización automática**: Sincroniza cambios cuando vuelve la conexión
- ✅ **Escaneo QR**: Usando la cámara del dispositivo o código manual
- ✅ **PWA**: Instalable como aplicación nativa
- ✅ **Validación local**: Escaneos validados 100% localmente
- ✅ **Cola de sincronización**: Maneja usos pendientes de sincronizar

## Stack Tecnológico

- **Framework**: Next.js 14+ con App Router
- **Lenguaje**: TypeScript
- **Estilos**: Tailwind CSS
- **Base de Datos**: Supabase (servidor) + IndexedDB (cliente)
- **Librerías**:
  - `html5-qrcode` para escaneo QR
  - `dexie` para IndexedDB
  - `@supabase/supabase-js` para conexión con Supabase

## Configuración Inicial

### 1. Instalar dependencias

```bash
npm install
```

### 2. Variables de entorno

Crear un archivo `.env.local` en la raíz del proyecto:

```env
NEXT_PUBLIC_SUPABASE_URL=https://tu-proyecto.supabase.co
SUPABASE_SERVICE_ROLE_KEY=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...
ADMIN_SECRET_KEY=tu-clave-secreta-aqui
```

**Nota**: Usa el **SERVICE ROLE KEY** de Supabase (no el anon key). Este key tiene permisos completos y solo se usa del lado del servidor.

### 3. Estructura de la tabla en Supabase

La tabla debe llamarse: `fiesta_china_individual_tickets`

Columnas requeridas:
- `id` (string)
- `order_id` (string)
- `holder_name` (string)
- `holder_email` (string)
- `ticket_type` (string)
- `qr_code` (string) - **Identificador único del ticket**
- `qr_code_url` (string)
- `is_used` (boolean)
- `used_at` (string | null)
- `scanned_by` (string | null)
- `created_at` (string)
- `updated_at` (string)

### 4. Iconos PWA

Crear las siguientes imágenes en `public/icons/`:
- `icon-192x192.png` (192x192px)
- `icon-512x512.png` (512x512px)

**Nota**: Por ahora el manifest referencia estos iconos. Si no los creas, la PWA funcionará pero sin iconos personalizados.

## Desarrollo

```bash
npm run dev
```

La aplicación estará disponible en `http://localhost:3000`

## Uso

### 1. Login

Al abrir la app, se solicita la clave de administrador (coincide con `ADMIN_SECRET_KEY`).

### 2. Carga inicial

Una vez autenticado, la app:
- Descarga un snapshot completo de todos los tickets desde Supabase
- Los guarda en IndexedDB para uso offline
- Intenta sincronizar cualquier uso pendiente previo

### 3. Escaneo

- La cámara se inicia automáticamente
- Escanea códigos QR o ingresa códigos manualmente
- Los tickets se validan localmente sin necesidad de Internet
- Los usos válidos se marcan localmente y se encolan para sincronización

### 4. Sincronización

- La sincronización se realiza automáticamente cuando hay conexión
- Se ejecuta cada 30 segundos si hay conexión
- Se ejecuta inmediatamente al detectar conexión (`window.online`)
- Muestra contador de pendientes por sincronizar

## Instalación como PWA

**⚠️ IMPORTANTE**: Antes de instalar, asegúrate de crear los iconos necesarios (ver `public/icons/INSTRUCCIONES_ICONOS.md`)

### Chrome/Edge (Android/Desktop)
1. Abrir la app en el navegador (debe ser HTTPS o localhost)
2. Ver el banner "Instalar app" o ir a menú (⋮) → "Instalar aplicación"
3. Confirmar instalación
4. La app se instalará como aplicación independiente

### Safari (iOS)
1. Abrir la app en Safari
2. Tocar el botón "Compartir" (cuadrado con flecha)
3. Seleccionar "Añadir a pantalla de inicio"
4. Personalizar el nombre si deseas
5. Tocar "Añadir"

### Desktop (Windows/Mac/Linux)
- **Chrome/Edge**: Mostrarán un banner de instalación en la barra de direcciones
- **Firefox**: No soporta instalación PWA directamente (pero la app funcionará)

## Funcionalidad Offline

La PWA está diseñada para funcionar completamente offline después del snapshot inicial:

### ✅ Funciona sin conexión:
- Escaneo de tickets (validación local)
- Marcado de tickets como usados
- Visualización del historial
- Búsqueda manual

### 🔄 Sincronización automática:
- Al volver la conexión, se sincronizan automáticamente los cambios pendientes
- Sincronización periódica cada 30 segundos cuando hay conexión
- Indicador visual de estado online/offline
- Contador de tickets pendientes por sincronizar

### 📱 Uso con mala señal:
- Timeout de 10 segundos en requests API
- Fallback a cache si la red es lenta
- Los escaneos se guardan localmente inmediatamente

## Actualización automática

Cuando hay una nueva versión de la PWA:
1. El service worker detecta la actualización
2. Se muestra una notificación al usuario
3. Al aceptar, la app se actualiza y recarga automáticamente

## Arquitectura

Ver `docs/architecture.md` para detalles completos de la arquitectura, estructura de carpetas, flujos de sincronización y más.

## API Routes

### POST /api/tickets/scan
Valida autenticación (mode: "ping") o busca un ticket por código QR.

### POST /api/tickets/use
Marca un ticket como usado en Supabase.

### GET /api/tickets/snapshot
Devuelve todos los tickets de la tabla.

**Todas las rutas requieren header**: `Authorization: Bearer ADMIN_SECRET_KEY`

## Consideraciones

- La app está diseñada para funcionar en dispositivos móviles
- Requiere permisos de cámara para escaneo QR
- Funciona mejor con buena iluminación para el QR
- Los escaneos duplicados se ignoran si ocurren en menos de 2 segundos
- Los sonidos de éxito solo funcionan si el dispositivo tiene audio habilitado

## Producción

```bash
npm run build
npm start
```

O despliega en Vercel/Netlify con las variables de entorno configuradas.

#   p w a - s c a n n e r 
 
 